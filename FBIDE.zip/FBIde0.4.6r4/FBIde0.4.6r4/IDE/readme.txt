FBIde 0.4:

   FBIde - is a free open source IDE for FreeBasic compiler written using 
   Dev-Cpp and wxWidgets framework library.
   Copyright (C) 2004-2005 Albert Varaksin [ vongodric@hotmail.com ]



License:

   This program is free software; you can redistribute it and/or modify it under 
   the terms of the GNU General Public License as published by the Free Software 
   Foundation; either version 2 of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful, but WITHOUT 
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
   FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along with 
   this program; if not, write to the Free Software Foundation, Inc., 59 Temple 
   Place, Suite 330, Boston, MA 02111-1307 USA.



Installing:

   Using installer: Run installer and select path where to install. On first run
                    FBIde will ask you for fbc path. After it enjoy.

   Using FBC+IDE:   Run installer, select path where to install and enjoy!

   Using rar/zip pacakage: extract ide somewhere, on first run it will ask you
                           fbc path, after it enjoy.



Requirements:

   - Any modern version of Microsoft windows since 95
   - 4MB hdd space
   - SVGA videocard
   - Mouse and keyboard



Basic features:

   - FB syntax highlight
   - indentation guides
   - Matching brace highlighting
   - Multilangual
   - Costomisible editing enviroment
   - Compilation support from within IDE
   - Tabbed enviroment
   - Code formatting and export to HTML/BBcode
   - and lot more ...



Links:

   - Official site: http://fbide.sourceforge.net or http://fbide.freebasic.net/
   - Sourceforge project page: http://www.sourceforge.net/projects/fbide/
   - FreeBasic official site: http://www.freebasic.net/



Credits:

   - dumbledore - code exporting and formatting routines
   - Madedog - internationalization (i18n) modules
   - Mecki - splash screen logo
   - MySoft - Many patches to fix FBIde



Betatesters:

   - Shadowolf	
   - AetherFox
   - Z!re
   - ak00ma
   - Adosorken
   - Whitetiger
   - DrV
   - shiftLynx
   - SJ Zero
   - Nexinarus



Language files by:

   - v!ct0r          - portuguese
   - Mecki           - german
   - MystikShadows   - french
   - Dutchtux        - dutch
   - E. Gerfanow     - russion
   - Rojalus Kele    - chinese
   - Drakontas       - greek
   - Shion           - japanese
   - N. Panaitoiu    - romanian
   - lurah           - finnish
   - etko            - slovak


...and everyone we forgot!

